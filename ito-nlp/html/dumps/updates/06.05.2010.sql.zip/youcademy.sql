--
-- Table structure for table `schools_assigned`
--

DROP TABLE IF EXISTS `schools_assigned`;
CREATE TABLE `schools_assigned` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
