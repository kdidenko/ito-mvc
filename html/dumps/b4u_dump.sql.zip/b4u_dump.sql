-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Время создания: Окт 07 2010 г., 11:19
-- Версия сервера: 5.0.27
-- Версия PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- База данных: `b4u`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `enabled` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  `birthday` date default NULL,
  `validation_id` varchar(32) NOT NULL,
  `role` varchar(2) NOT NULL,
  `avatar` varchar(255) default NULL,
  `skype` varchar(255) default NULL,
  `gender` varchar(6) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

-- 
-- Дамп данных таблицы `users`
-- 

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `crdate`, `modified`, `enabled`, `deleted`, `birthday`, `validation_id`, `role`, `avatar`, `skype`, `gender`) VALUES 
(4, 'Administrator', 'YouCademy', 'admin@youcademy.com', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-04-26 13:29:14', '2010-05-07 19:04:29', 1, 0, NULL, '840c3eda3ea42ecd90aeb3434f3510b7', 'AR', 'storage/uploads/users/admin/profile/avatar.jpg', NULL, NULL),
(37, 'moderator', 'moderator', 'moderator@gmail.com', 'moderator', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-06-16 09:38:00', '2010-06-16 12:38:42', 1, 0, NULL, 'f69e505b08403ad2298b9f262659929a', 'MR', 'storage/uploads/users/moderator/profile/avatar.jpg', NULL, NULL),
(41, 'John', 'Volt', 'john@gmail.com', 'user2', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-06-27 11:21:50', '2010-06-27 15:12:33', 1, 0, NULL, '4c8c76b39d294759a9000cbda3a6571a', 'MR', 'storage/uploads/users/user2/profile/avatar.jpg', NULL, NULL),
(40, 'Bill', 'Gates', 'bill@gmail.com', 'user1', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-06-27 11:21:13', '2010-06-27 14:23:56', 1, 0, NULL, 'e0c7ccc47b2613c82d1073a4214deecc', 'UR', 'storage/uploads/users/user1/profile/avatar.jpg', NULL, NULL),
(42, 'Riky', 'Volly', 'rick@gmail.com', 'user4', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-06-27 11:23:01', '2010-06-27 14:23:56', 1, 0, NULL, '309928d4b100a5d75adff48a9bfc1ddb', 'UR', 'storage/uploads/users/user4/profile/avatar.jpg', NULL, NULL),
(43, 'Andrew', 'Stabryn', 'astabryn@gmail.com', 'astabryn', 'e10adc3949ba59abbe56e057f20f883e', '2010-10-07 13:42:52', '2010-10-07 17:08:16', 1, 0, '2000-09-07', '9a1de01f893e0d2551ecbb7ce4dc963e', 'UR', 'storage/uploads/users/user4/profile/avatar.jpg', '', 'Male');
