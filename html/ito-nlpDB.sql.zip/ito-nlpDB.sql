-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Час створення: Лют 08 2010 р., 19:39
-- Версія сервера: 5.0.85
-- Версія PHP: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- БД: `ito_trainings`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблиці `otp_users`
-- 

CREATE TABLE `otp_users` (
  `id` int(10) NOT NULL auto_increment,
  `user_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `user_lastname` varchar(255) collate utf8_unicode_ci NOT NULL,
  `user_password` varchar(32) collate utf8_unicode_ci NOT NULL,
  `user_email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `user_birthday` date NOT NULL,
  `user_create` date NOT NULL,
  `user_status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

-- 
-- Дамп даних таблиці `otp_users`
-- 

INSERT INTO `otp_users` (`id`, `user_name`, `user_lastname`, `user_password`, `user_email`, `user_birthday`, `user_create`, `user_status`) VALUES 
(1, 'Andrew', 'Stabryn', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmail.com', '2010-01-01', '2010-02-08', 0),
(2, 'Andrew', 'Stabryn', '96e79218965eb72c92a549dd5a330112', 'astabryns@gmail.com', '2010-01-01', '2010-02-08', 0),
(3, 'Andrew', 'Stabryn', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabrynds@gmail.com', '2010-01-01', '2010-02-08', 0),
(4, 'fsa', 'fa', '16fcb1091f8a0cc70c96e2ff97fdd213', 'astabryn@gmail.comss', '2010-01-01', '2010-02-08', 0),
(5, 'fsa', 'fa', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabryn@gmail.comjhss', '2010-01-01', '2010-02-08', 0),
(6, 'fsa', 'fa', 'af15d5fdacd5fdfea300e88a8e253e82', 'astabryn@gmasil.comjhss', '2010-01-01', '2010-02-08', 0),
(7, 'fsa', 'fa', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmsasil.comjhss', '2010-01-01', '2010-02-08', 0),
(8, 'fsa', 'fa', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmsa1sil.comjhss', '2010-01-01', '2010-02-08', 0),
(9, 'fsa', 'fa', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabryn@gmasa1sil.comjhss', '2010-01-01', '2010-02-08', 0),
(10, 'fsa', 'fa', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmasa1sil.comjhsss', '2010-01-01', '2010-02-08', 0),
(11, 'fsa', 'fa', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmasa1sil.comjhssg', '2010-01-01', '2010-02-08', 0),
(12, 'fsa', 'fa', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmasa1sil.comjhssa', '2010-01-01', '2010-02-08', 0),
(13, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabryn@gmail.comhg', '2010-01-01', '2010-02-08', 0),
(14, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabryn@gsmail.comhg', '2010-01-01', '2010-02-08', 0),
(15, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astaabryn@gsmail.comhg', '2010-01-01', '2010-02-08', 0),
(16, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astaabaryn@gsmail.comhg', '2010-01-01', '2010-02-08', 0),
(17, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astaabaaryn@gsmail.comhg', '2010-01-01', '2010-02-08', 0),
(18, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astaabaaaryn@gsmail.comhg', '2010-01-01', '2010-02-08', 0),
(19, 'a', 'a', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmail.comgfds', '2010-01-01', '2010-02-08', 0),
(20, 'a', 'a', '96e79218965eb72c92a549dd5a330112', 'astabryan@gmail.comgfds', '2010-01-01', '2010-02-08', 1),
(21, 'a', 'a', '96e79218965eb72c92a549dd5a330112', 'astabryn@gmail.comdas', '2010-01-01', '2010-02-08', 1),
(22, 'a', 'a', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'astabryn@gmail.comasa', '2010-01-01', '2010-02-08', 1),
(23, 'Ñ‹Ð²Ñ„', 'Ñ‹Ñ„', '7fa8282ad93047a4d6fe6111c93b308a', 'astabryn@gmail.comaasa', '2010-01-01', '2010-02-08', 0);
