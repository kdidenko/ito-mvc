--
-- Table structure for table `exercises`
--

DROP TABLE IF EXISTS `exercises`;
CREATE TABLE `exercises` (
  `id` int(11) NOT NULL auto_increment,
  `caption` varchar(255) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `owner_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL default '0',
  `course_id` int(11) default NULL,
  `video` varchar(1000) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

INSERT INTO `exercises` (`id`, `caption`, `description`, `crdate`, `modified`, `owner_id`, `rate`, `course_id`, `video`) VALUES 
(14, 'NLP eye patterns - eye access cues ', 'Join master hypnotist and nlp practitioner Alan as he explains eye access cues.\r\n\r\nObserving eye access cues during a conversation allows you to build rapport quickly and easily and also understand someones strategy for doing things.\r\n\r\nWant to know how someone buys something, ask them to think of a previous time when they bought and watch the eye access movements. These movements will tell you whether they picture, feel or hear something and in what order when making a purchasing decision.', '2010-05-12 09:40:39', '0000-00-00 00:00:00', 36, 0, NULL, '<object width="560" height="340"><param name="movie" value="http://www.youtube-nocookie.com/v/oWfmnKAStAw&hl=ru_RU&fs=1&rel=0"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube-nocookie.com/v/oWfmnKAStAw&hl=ru_RU&fs=1&rel=0" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="560" height="340"></embed></object>'),
(11, 'Change your perspective ', 'When we change the way we look at things, the things we look at change. Find new ways to look at your problems with NLP and new solutions will appear like magic!\r\n\r\nThis fun interactive exercise will help you see just how easy it is to change your perspective and find happiness!', '2010-05-12 09:25:38', '2010-05-12 12:28:13', 4, 0, NULL, '<object width="560" height="340"><param name="movie" value="http://www.youtube-nocookie.com/v/v4LiI7X3Nlo&hl=ru_RU&fs=1&rel=0"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube-nocookie.com/v/v4LiI7X3Nlo&hl=ru_RU&fs=1&rel=0" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="560" height="340"></embed></object>'),
(12, 'Improve your mood with nlp anchoring ', 'Learn to use Anchoring to access powerful states and improve your mood any time you desire. NLP provides many tools to help people be their best, anchoring is a powerful tool to help people access positive states whenever they desire.', '2010-05-12 09:34:16', '0000-00-00 00:00:00', 36, 0, NULL, '<object width="560" height="340"><param name="movie" value="http://www.youtube-nocookie.com/v/hGK-tG4RxZc&hl=ru_RU&fs=1&rel=0"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube-nocookie.com/v/hGK-tG4RxZc&hl=ru_RU&fs=1&rel=0" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="560" height="340"></embed></object>');