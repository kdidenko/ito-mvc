<?
include("header.php");
?>
<p>
  <?=$_GET['message']?>


</p>
<p></b><a href="recorded_videos.php">Browse Video Recordings</a></p>
