-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Час створення: Квт 26 2010 р., 09:32
-- Версія сервера: 5.0.27
-- Версія PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- БД: `youcademy`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблиці `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `enabled` tinyint(1) NOT NULL default '1',
  `deleted` tinyint(1) NOT NULL default '0',
  `birthday` date default NULL,
  `validation_id` varchar(32) NOT NULL,
  `role` varchar(2) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Дамп даних таблиці `users`
-- 

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `crdate`, `modified`, `enabled`, `deleted`, `birthday`, `validation_id`, `role`) VALUES 
(1, 'Andrew', 'Stabryn', 'astabryn@gmail.com', 'astabryn', '96e79218965eb72c92a549dd5a330112', '2010-04-25 11:11:43', '0000-00-00 00:00:00', 1, 0, NULL, '8004d637b6236202217be3dfcdd8ce59', ''),
(2, 'first', 'last', 'test@gmail.com', 'test', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-04-25 14:28:16', '0000-00-00 00:00:00', 1, 0, NULL, 'bb921944c8c4531826da3fa99b494c1a', '');
