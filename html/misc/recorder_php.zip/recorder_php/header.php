<style type="text/css">
<!--
a {
	color: #F96;
	font-weight: normal;
	text-decoration: none;
}
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 15px;
	color: #666;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	letter-spacing: -1px;
	background-color: #fff;
}
.info
{
	text-align:left;
	padding: 10px;
	margin: 10px;
	background-color: #FAF4E2;
	border: 1px dotted #390;
}
input {
	border: 1px solid #BBB;
	color: #666;
	font-weight: normal;
}
-->
</style>
<BODY>
<div style="background-color:#333; padding:10px; font-size:17px"><font color="#CCCCCC">VideoWhisper <a href="http://www.videowhisper.com/?p=Video+Recorder">Video Recorder</a></font></div>