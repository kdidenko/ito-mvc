<?
include("header.php");
?>
<p>Recording Result:
  <?=$_GET['result']?>
  
  
</p>
<p></b><a href="recorded_videos.php">Browse Video Recordings</a></p>
