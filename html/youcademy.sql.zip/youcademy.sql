-- MySQL dump 10.10
--
-- Host: localhost    Database: youcademy
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exercises`
--

DROP TABLE IF EXISTS `exercises`;
CREATE TABLE `exercises` (
  `id` int(11) NOT NULL auto_increment,
  `caption` varchar(255) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `owner_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exercises`
--

LOCK TABLES `exercises` WRITE;
/*!40000 ALTER TABLE `exercises` DISABLE KEYS */;
INSERT INTO `exercises` VALUES (1,'NLP','this is first test description for NLP','2010-04-30 12:56:23','2010-05-01 11:07:38',4,1),(5,'Sleight of Mouth','Positive Intension\r\nAsk yourself: \"What is the positive purpose, or intention of the belief behind the challenge?\", \"How is this valuable ...','2010-05-01 09:53:51','0000-00-00 00:00:00',4,0);
/*!40000 ALTER TABLE `exercises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
CREATE TABLE `schools` (
  `id` int(11) NOT NULL auto_increment,
  `alias` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `admin_id` int(11) NOT NULL,
  `fee_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;

INSERT INTO `schools` (`id`, `alias`, `caption`, `description`, `avatar`, `crdate`, `modified`, `admin_id`, `fee_id`, `rate`) VALUES 
(2, 'NLP', 'Richard Bandler', 'Here you can learn from the Master himself and his team!', 'storage/uploads/schools/NLP/avatar.jpg', '2010-05-01 13:57:50', '2010-05-01 21:25:12', 4, 0, 0),
(5, 'UoM', 'University of Maryland. University college.', 'Market yourself to employers, make more money or earn more responsibility at your current job. The emergence of a truly global business environment has made advanced business training more important than ever.', 'storage/uploads/schools/UoM/avatar.jpg', '2010-05-01 15:26:38', '0000-00-00 00:00:00', 4, 0, 0),
(10, 'NMTI', 'National Massage Therapy Institute', 'Get the Training You Need\r\n\r\nAt NMTI, your courses will help you build a solid foundation in Swedish Massage plus additional skills in Sports Massage, Reflexology, Shiatsu, Business Skills and more.\r\n\r\nSuccessful program completion leads to a diploma and qualifies you to sit for the National Certification Exam in Therapeutic Massage and Bodywork, which is required for licensing in most states. ', 'storage/uploads/schools/NMTI/avatar.jpg', '2010-05-02 11:40:48', '0000-00-00 00:00:00', 4, 0, 0),
(9, 'Sedona', 'Bennett/Stellar University ', ' This is it! If you want to enhance your career, your personal life, and learn lots of cool cutting edge techniques--you have found a home with Bennett/Stellar University.\r\n\r\nWe specialize in integrating Neuro-Linguistic Programming (NLP), Life Coaching, Hypnotherapy, and Reiki. What is NLP? How does Hypnotherapy work? What is Life Coaching and how do you become one? Answers to your questions can be found by inquiring for more info.\r\n\r\nLike-minded individuals from all over the world come to Bennett/Stellar University to discover personal development and master health enriching skills with the power of the mind, advanced communication, and energy. ', 'storage/uploads/schools/Sedona/avatar.jpg', '2010-05-02 11:37:52', '0000-00-00 00:00:00', 4, 0, 0);

/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `crdate` datetime NOT NULL,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `enabled` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  `birthday` date default NULL,
  `validation_id` varchar(32) NOT NULL,
  `role` varchar(2) NOT NULL,
  `avatar` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (4,'Administrator','YouCademy','admin@youcademy.com','admin','5f4dcc3b5aa765d61d8327deb882cf99','2010-04-26 13:29:14','2010-04-29 15:02:31',1,0,NULL,'840c3eda3ea42ecd90aeb3434f3510b7','AR','storage/uploads/users/admin/profile/avatar.jpg'),(13,'Andrew','Stabryn','astabryn@gmail.com','astabryn','96e79218965eb72c92a549dd5a330112','2010-04-28 12:30:24','2010-04-30 13:33:56',1,0,NULL,'8698ff92115213ab187d31d4ee5da8ea','UR','storage/uploads/users/astabryn/profile/avatar.jpg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-05-01 12:19:46
