<?php

$rtmp_server="rtmp://localhost/vwrec";
// rtmp://your-server-ip-or-domain/application

$rtmp_amf="AMF3";
// AMF3 : Red5, Wowza, FMIS3, FMIS3.5
// AMF0 : FCS1.5, FMS2
// blank for flash default

?>